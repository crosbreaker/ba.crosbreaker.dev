import './background/commands.js';
import './background/setup.js';
import './background/webstore-fix.js';
