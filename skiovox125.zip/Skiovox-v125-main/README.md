# How to get skiovox on v125 (v126 may work)
1. Logout of your account (not completely, just get to the login page)
2. Turn off your wifi
3. Enter a kiosk app (bottom left corner is a button called "Apps", if it isn't there than this exploit will not work)
4. Wait until it allows you to add a network, then click add a network with a random name (for example "a")
(Do the next steps as quickly as possible, because there is a time limit)
5. Now quickly click "diagnose", then click "wifi", and "open in settings". (The settings window will open behind the kiosk window so you can't see it)
6. Close the diagnose popup, and quickly do "Ctrl + Alt + Shift + R"
7. It will now say "Powerwash your chromebook", but instead of powerwashing we press cancel, and you need to quickly login.

(Now it is safe to take your time)

There are three methods to get to the unmanaged window:

A. You close the managed window. (You can't get it back)

B. You double click the top of the managed window (This will make it so that the managed window is difficult to get back in fullscreen)

C. You open the settings menu, click "More tools", and open the task manager. Then you double click a window called "Settings" (The obvious best way)


Yay! You are now done with the first steps.

## We still need to:
1. Go to the settings menu, and click on new window. (This will give you a better window and is required to do the next step)

2. Install the extension (You only have to install the extension once):
Go to 'https://github.com/blitzbrian/Skiovox-v125' and press the green code button and click download as zip.

Go to 'chrome://extensions', and enable developer mode (Top right corner).

Click 'Load unpacked extension', and right click on the zip you downloaded and extract it.

Now double click on the newly created folder and click 'Select folder'.

And then you need to put in all of the shortcuts, it says which combination you need to press between the brackets.


Congrats, now you are done!

## Tips:
I'm stuck in fullscreen help!

Press 'Ctrl+T' and then the fullscreen button.

## Credits:
444amogus

Eth3r (v124 exploit)

Bypassi (original exploit)

Me (for the repo and the extension)
